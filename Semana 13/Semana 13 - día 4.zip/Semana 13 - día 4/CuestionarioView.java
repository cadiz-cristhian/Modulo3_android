package com.cris.apppeliculav01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import Controller.CuestionarioController;

public class CuestionarioView extends AppCompatActivity {

    public TextView pregunta;
    public RadioButton respuestaA, respuestaB, respuestaC, respuestaD;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuestionario);




    }




}