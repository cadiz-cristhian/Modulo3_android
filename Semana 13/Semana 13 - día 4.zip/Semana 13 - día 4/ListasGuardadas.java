package com.cris.apppeliculav01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListasGuardadas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listas_guardadas);
    }
}